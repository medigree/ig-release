Empty IG
---
This is an empty IG
<br> </br>
###
### Publication
This ImplementationGuide is published in the following locations:

Continuous Build: __http://build.fhir.org/ig/openhie/fhir-ig-empty/branches/main/index.html__  
Canonical / permanent URL: 
<br> </br>

### Issues
Issues and change requests are managed here:  

Issues:  __https://github.com/openhie/fhir-ig-empty/issues__  
Kanban board:  __https://github.com/openhie/fhir-ig-empty/projects/1__  

---

